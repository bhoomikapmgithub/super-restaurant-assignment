/*
  Warnings:

  - You are about to drop the column `createdAt` on the `VerificationCode` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "VerificationCode" DROP COLUMN "createdAt";
