-- AlterTable
ALTER TABLE "VerificationCode" ADD COLUMN     "used" BOOLEAN NOT NULL DEFAULT false;
