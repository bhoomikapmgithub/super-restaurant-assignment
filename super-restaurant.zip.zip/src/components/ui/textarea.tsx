// src/components/ui/textarea.tsx
import React from "react";

export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`block w-full rounded border px-3 py-2 min-h-[100px] resize-vertical ${props.className || ""}`}
    />
  );
}