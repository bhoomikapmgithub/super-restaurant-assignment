// server/db.ts
import { PrismaClient } from "@prisma/client";

declare global {
  var __prisma: PrismaClient | undefined;
}

export const db =
  global.__prisma ??
  new PrismaClient({
    log: ["query", "warn"],
  });

if (process.env.NODE_ENV !== "production") {
  global.__prisma = db;
}