"use client";

import React, { useEffect, useState, useRef } from "react";
import QRCode from "qrcode";

export default function PublicMenu({ params }: any) {
  const { slug } = React.use(params);
  const [restaurant, setRestaurant] = useState<any>(null);
  const [categories, setCategories] = useState<any[]>([]);
  const [dishes, setDishes] = useState<any[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!slug) return;
    load();
    generateQR();
  }, [slug]);

  async function load() {
    try {
      const r = await fetch(`/api/restaurants/${slug}`);
      const j = await r.json();
      setRestaurant(j);

      const rc = await fetch(`/api/restaurants/${slug}/categories`);
      const cats = await rc.json();
      setCategories(cats);

      const rd = await fetch(`/api/restaurants/${slug}/dishes`);
      const ds = await rd.json();
      setDishes(ds);

      if (cats[0]) setActive(cats[0].id);
    } catch (err) {
      console.error(err);
    }
  }

  async function generateQR() {
    try {
      const url = `${location.origin}/menu/${slug}`;
      const dataUrl = await QRCode.toDataURL(url, { width: 300 });
      setQrDataUrl(dataUrl);
    } catch (err) {
      console.error("QR error", err);
    }
  }

  // simple client cart
  const [cart, setCart] = useState<{ id: string; name: string; qty: number; price: number }[]>([]);
  function addToCart(item: any) {
    setCart((c) => {
      const found = c.find((x) => x.id === item.id);
      if (found) return c.map((x) => (x.id === item.id ? { ...x, qty: x.qty + 1 } : x));
      return [...c, { id: item.id, name: item.name, qty: 1, price: item.price }];
    });
  }
  function total() {
    return cart.reduce((s, i) => s + i.price * i.qty, 0);
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-4xl mx-auto p-6">
        <header className="py-6 border-b mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">{restaurant?.name || "Restaurant"}</h1>
              <p className="text-sm text-gray-500">{restaurant?.location}</p>
            </div>

            <div className="text-right">
              {qrDataUrl ? <img src={qrDataUrl} className="w-24 h-24 border rounded" alt="QR" /> : null}
              <div className="text-xs text-gray-500 mt-1">Scan for this menu</div>
            </div>
          </div>
        </header>

        <div className="flex gap-6">
          {/* Category list (sticky left on desktop) */}
          <aside className="hidden md:block w-48 sticky top-24 h-[60vh] overflow-auto pr-4">
            <nav className="space-y-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  className={`block w-full text-left p-2 rounded ${active === cat.id ? "bg-pink-600 text-white" : "text-gray-700"}`}
                  onClick={() => {
                    setActive(cat.id);
                    const el = document.getElementById(`cat-${cat.id}`);
                    el?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }}
                >
                  {cat.name}
                </button>
              ))}
            </nav>
          </aside>

          {/* Menu content */}
          <main className="flex-1">
            {categories.length === 0 && <p className="text-gray-500">No categories yet</p>}

            {categories.map((cat) => (
              <section key={cat.id} id={`cat-${cat.id}`} className="mb-8">
                <h2 className="text-2xl font-semibold border-b pb-2">{cat.name}</h2>

                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  {dishes
                    .filter((d: any) => (!d.categories || d.categories.length === 0) ? true : d.categories.some((c:any) => c.id === cat.id))
                    .map((dish: any) => (
                      <article key={dish.id} className="p-4 border rounded flex">
                        {dish.image ? <img src={dish.image} alt={dish.name} className="w-28 h-20 object-cover rounded mr-4" /> : <div className="w-28 h-20 bg-gray-100 rounded mr-4" />}
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <h3 className="font-semibold">{dish.name}</h3>
                            <div className="font-semibold">₹ {dish.price}</div>
                          </div>
                          <p className="text-sm text-gray-600">{dish.description}</p>
                          <div className="mt-2">
                            <button onClick={() => addToCart(dish)} className="bg-pink-600 text-white px-3 py-1 rounded">Add</button>
                          </div>
                        </div>
                      </article>
                    ))}
                </div>
              </section>
            ))}
          </main>
        </div>
      </div>

      {/* Floating mobile category bar */}
      <div className="fixed bottom-20 left-3 right-3 md:hidden">
        <div className="bg-white shadow rounded p-2 overflow-auto flex gap-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              className={`px-3 py-2 rounded ${active === cat.id ? "bg-pink-600 text-white" : "bg-gray-100"}`}
              onClick={() => {
                setActive(cat.id);
                const el = document.getElementById(`cat-${cat.id}`);
                el?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Floating Cart */}
      <div className="fixed right-6 bottom-6">
        <div className="bg-white border rounded-lg shadow p-4 w-80">
          <h4 className="font-semibold">Cart</h4>
          {cart.length === 0 && <div className="text-sm text-gray-500">No items</div>}
          {cart.map((c) => (
            <div key={c.id} className="flex justify-between mt-2">
              <div>
                <div className="font-medium">{c.name}</div>
                <div className="text-sm text-gray-500">Qty: {c.qty}</div>
              </div>
              <div className="font-semibold">₹ {c.qty * c.price}</div>
            </div>
          ))}
          <div className="mt-3 border-t pt-3 flex justify-between items-center">
            <div className="font-semibold">Total</div>
            <div className="font-bold">₹ {total()}</div>
          </div>
        </div>
      </div>
    </div>
  );
}