"use client";

import React, { useEffect, useState } from "react";

export default function DashboardPage() {
  const [restaurants, setRestaurants] = useState<any[]>([]);

  useEffect(() => {
    async function load() {
      const res = await fetch(`/api/restaurants?email=<your-user-email>`); // adapt
      const j = await res.json();
      setRestaurants(j || []);
    }
    load();
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Your Restaurants</h1>
      <button className="bg-black text-white px-4 py-2 rounded">+ Add New Restaurant</button>

      <div className="mt-6">
        {restaurants.length === 0 ? <p>No restaurants created yet.</p> : restaurants.map((r) => (
          <div key={r.id} className="p-4 border rounded mt-4">
            <h2 className="font-semibold">{r.name}</h2>
            <p className="text-gray-500">{r.location}</p>
            <div className="mt-2 flex gap-2">
              <a className="text-sm underline" href={`/dashboard/restaurants/${r.slug}/categories`}>Categories</a>
              <a className="text-sm underline" href={`/dashboard/restaurants/${r.slug}/dishes`}>Dishes</a>
              <a className="text-sm underline" target="_blank" href={`/menu/${r.slug}`}>View menu</a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}