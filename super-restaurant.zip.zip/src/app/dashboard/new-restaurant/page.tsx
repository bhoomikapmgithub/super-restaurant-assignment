"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";

export default function NewRestaurantPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [loading, setLoading] = useState(false);

  const createRestaurant = async () => {
    setLoading(true);

    const email = localStorage.getItem("userEmail");
    if (!email) {
      alert("Login again!");
      return router.push("/login");
    }

    const res = await fetch("/api/restaurants", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, location, email }),
    });

    setLoading(false);

    if (res.ok) {
      router.push("/dashboard");
    } else {
      alert("Failed to create restaurant");
    }
  };

  return (
    <div className="max-w-lg mx-auto mt-12 p-6 border rounded-lg shadow-lg bg-white">
      <h1 className="text-2xl font-semibold mb-4">Create New Restaurant</h1>

      <div className="space-y-4">
        <Input
          placeholder="Restaurant Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <Input
          placeholder="Location"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
        />

        <Button className="w-full" onClick={createRestaurant} disabled={loading}>
          {loading ? "Creating..." : "Create Restaurant"}
        </Button>
      </div>
    </div>
  );
}