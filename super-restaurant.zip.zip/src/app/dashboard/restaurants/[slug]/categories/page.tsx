"use client";

import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import React from "react";

export default function CategoriesPage({ params }: any) {
  const { slug } = React.use(params); // ✅ FIXED

  const [categories, setCategories] = useState<any[]>([]);
  const [newName, setNewName] = useState("");
  const [loading, setLoading] = useState(false);

  async function loadCategories() {
    const res = await fetch(`/api/categories?slug=${slug}`);
    const data = await res.json();
    setCategories(data);
  }

  async function addCategory() {
    if (!newName.trim()) return;
    setLoading(true);

    await fetch("/api/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName, slug }),
    });

    setNewName("");
    setLoading(false);
    loadCategories();
  }

  useEffect(() => {
    if (slug) loadCategories();
  }, [slug]);

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Categories</h1>

      <div className="flex gap-2 mb-6">
        <Input
          placeholder="New category name"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
        />
        <Button onClick={addCategory} disabled={loading}>
          {loading ? "Adding..." : "Add"}
        </Button>
      </div>

      {categories.length === 0 && (
        <p className="text-gray-500">No categories yet.</p>
      )}

      {categories.map((cat) => (
        <div key={cat.id} className="p-4 border rounded shadow-sm bg-white">
          {cat.name}
        </div>
      ))}
    </div>
  );
}