"use client";

export default function RestaurantOverview({ params }: any) {
  const { slug } = React.use(params);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">Restaurant Dashboard</h1>

      <div className="mt-6 space-x-4">
        <a href={`/dashboard/restaurants/${slug}/categories`} className="px-4 py-2 bg-black text-white rounded">
          Manage Categories
        </a>

        <a href={`/dashboard/restaurants/${slug}/dishes`} className="px-4 py-2 bg-black text-white rounded">
          Manage Dishes
        </a>

        <a href={`/menu/${slug}`} className="px-4 py-2 bg-blue-600 text-white rounded">
          View Public Menu
        </a>
      </div>
    </div>
  );
}