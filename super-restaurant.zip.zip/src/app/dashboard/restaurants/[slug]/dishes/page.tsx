"use client";

import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function DishesPage({ params }: any) {
  const { slug } = React.use(params); // ✅ FIXED

  const [categories, setCategories] = useState([]);
  const [dishes, setDishes] = useState([]);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [price, setPrice] = useState("");

  async function loadPage() {
    const cats = await fetch(`/api/categories?slug=${slug}`).then((r) =>
      r.json()
    );
    const dis = await fetch(`/api/dishes?slug=${slug}`).then((r) => r.json());

    setCategories(cats);
    setDishes(dis);
  }

  async function addDish(e: any) {
    e.preventDefault();

    await fetch(`/api/dishes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        slug,
        name,
        description: desc,
        price,
      }),
    });

    setName("");
    setDesc("");
    setPrice("");
    loadPage();
  }

  useEffect(() => {
    if (slug) loadPage();
  }, [slug]);

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Dishes</h1>

      <form onSubmit={addDish} className="space-y-3 border p-4 rounded bg-white">
        <Input
          placeholder="Dish name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <Textarea
          placeholder="Description"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
        />

        <Input
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />

        <Button type="submit">Add Dish</Button>
      </form>

      <h2 className="text-xl font-semibold mt-6">Existing Dishes</h2>

      {dishes.length === 0 && <p className="text-gray-500">No dishes yet.</p>}

      {dishes.map((d: any) => (
        <div key={d.id} className="p-4 border rounded mt-3 bg-white">
          <div className="font-bold">{d.name}</div>
          <div className="text-gray-600">{d.description}</div>
          <div className="font-semibold mt-1">₹ {d.price}</div>
        </div>
      ))}
    </div>
  );
}