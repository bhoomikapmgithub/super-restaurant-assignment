import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const email = searchParams.get("email");

    if (!email) return NextResponse.json([]);

    const user = await prisma.user.findUnique({
      where: { email },
    });

    if (!user) return NextResponse.json([]);

    const restaurants = await prisma.restaurant.findMany({
      where: { ownerId: user.id },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(restaurants);
  } catch (err) {
    return NextResponse.json({ error: "GET failed" }, { status: 400 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, location, email } = body;

    if (!name || !location || !email)
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });

    const user = await prisma.user.findUnique({
      where: { email },
    });

    if (!user)
      return NextResponse.json({ error: "User not found" }, { status: 404 });

    const slug = name.toLowerCase().replace(/\s+/g, "-");

    const restaurant = await prisma.restaurant.create({
      data: {
        name,
        location,
        slug,
        ownerId: user.id,
      },
    });

    return NextResponse.json(restaurant);
  } catch (err) {
    return NextResponse.json({ error: "POST failed" }, { status: 500 });
  }
}