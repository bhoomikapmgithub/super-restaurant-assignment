// src/app/api/restaurants/route.ts
import { NextResponse } from "next/server";

// mock response for testing. Replace with real prisma code later.
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const email = searchParams.get("email") || "";

    // if you have prisma, fetch using prisma.user.findUnique + related restaurants
    // For now return dummy data so UI can render and you can proceed.
    if (!email) {
      return NextResponse.json({ restaurants: [] });
    }

    const restaurants = [
      { id: "r1", name: "ABC", location: "Bengaluru", slug: "abc" },
    ];

    return NextResponse.json({ restaurants });
  } catch (err) {
    console.error("API /api/restaurants error:", err);
    return NextResponse.json({ error: "internal" }, { status: 500 });
  }
}