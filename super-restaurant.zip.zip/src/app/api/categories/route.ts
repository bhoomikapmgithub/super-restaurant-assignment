// src/app/api/categories/route.ts
import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const slug = searchParams.get("slug");

    if (!slug) return NextResponse.json([]);

    const restaurant = await prisma.restaurant.findUnique({ where: { id: slug } }) // using id as slug for simplicity
    // If you use a slug field, change to: where: { slug }

    if (!restaurant) return NextResponse.json([]);

    const categories = await prisma.category.findMany({
      where: { restaurantId: restaurant.id },
      orderBy: { createdAt: "asc" },
    });

    return NextResponse.json(categories);
  } catch (err) {
    console.error(err);
    return NextResponse.json([], { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const { name, slug } = await req.json(); // slug = restaurant id or slug

    if (!name || !slug) return NextResponse.json({ error: "name and slug required" }, { status: 400 });

    const restaurant = await prisma.restaurant.findUnique({ where: { id: slug } });
    // If you use slug field, change above.

    if (!restaurant) return NextResponse.json({ error: "restaurant not found" }, { status: 404 });

    const category = await prisma.category.create({
      data: {
        name,
        restaurantId: restaurant.id,
      },
    });

    return NextResponse.json(category);
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}