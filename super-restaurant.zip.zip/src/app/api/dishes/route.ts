// src/app/api/dishes/route.ts
import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const slug = searchParams.get("slug");

    if (!slug) return NextResponse.json([]);

    const restaurant = await prisma.restaurant.findUnique({ where: { id: slug } });
    if (!restaurant) return NextResponse.json([]);

    const dishes = await prisma.dish.findMany({
      where: { restaurantId: restaurant.id },
      include: { images: true, categories: true },
      orderBy: { createdAt: "asc" },
    });

    return NextResponse.json(dishes);
  } catch (err) {
    console.error(err);
    return NextResponse.json([], { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, description, price, categoryId, image, slug } = body;

    if (!name || !price || !slug) return NextResponse.json({ error: "missing fields" }, { status: 400 });

    const restaurant = await prisma.restaurant.findUnique({ where: { id: slug } });
    if (!restaurant) return NextResponse.json({ error: "restaurant not found" }, { status: 404 });

    const dish = await prisma.dish.create({
      data: {
        name,
        description: description || "",
        price: Number(price),
        restaurantId: restaurant.id,
      },
    });

    // attach image if present
    if (image) {
      await prisma.image.create({
        data: {
          url: image,
          dishId: dish.id,
        },
      });
    }

    // attach category if provided
    if (categoryId) {
      await prisma.category.update({
        where: { id: categoryId },
        data: {
          dishes: { connect: { id: dish.id } },
        },
      });
    }

    const created = await prisma.dish.findUnique({
      where: { id: dish.id },
      include: { images: true, categories: true },
    });

    return NextResponse.json(created);
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}