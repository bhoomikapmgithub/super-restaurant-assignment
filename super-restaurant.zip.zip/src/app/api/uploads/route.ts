// src/app/api/upload/route.ts
import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { filename, data } = body;
    if (!filename || !data) return NextResponse.json({ error: "filename and data required" }, { status: 400 });

    // data is expected to be "data:image/png;base64,...."
    const matches = data.match(/^data:(.+);base64,(.+)$/);
    if (!matches) return NextResponse.json({ error: "Invalid data URL" }, { status: 400 });

    const mime = matches[1];
    const b64 = matches[2];
    const buffer = Buffer.from(b64, "base64");

    const uploadsDir = path.join(process.cwd(), "public", "uploads");
    if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

    // create unique name
    const ext = filename.split(".").pop() || "png";
    const name = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}.${ext}`;
    const filePath = path.join(uploadsDir, name);

    fs.writeFileSync(filePath, buffer);

    const url = `/uploads/${name}`;

    return NextResponse.json({ url });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "upload failed" }, { status: 500 });
  }
}