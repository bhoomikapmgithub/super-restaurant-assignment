import { NextResponse } from "next/server";
import { db } from "@/server/db";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const email = (body?.email || "").toString().trim().toLowerCase();
    const code = (body?.code || "").toString().trim();

    if (!email || !code) {
      return NextResponse.json({ error: "Email and code are required" }, { status: 400 });
    }

    const now = new Date();

    const record = await db.verificationCode.findFirst({
      where: {
        email,
        code,
        used: false,
        expiresAt: { gte: now },
      },
    });

    if (!record) {
      return NextResponse.json({ error: "Invalid or expired code" }, { status: 400 });
    }

    await db.verificationCode.update({
      where: { id: record.id },
      data: { used: true },
    });

    return NextResponse.json({ ok: true, message: "Verified" }, { status: 200 });
  } catch (err) {
    console.error("VERIFY CODE ERROR:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}