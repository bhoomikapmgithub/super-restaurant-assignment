import { NextResponse } from "next/server";
import { v4 as uuidv4 } from "uuid";
import { db } from "@/server/db";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const email = (body?.email || "").toString().trim().toLowerCase();

    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 });
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await db.verificationCode.create({
      data: {
        id: uuidv4(),
        email,
        code,
        expiresAt,
        used: false,
      },
    });

    console.log("OTP sent:", code);

    return NextResponse.json({ ok: true, message: "Code sent" }, { status: 200 });
  } catch (err) {
    console.error("SEND CODE ERROR:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}