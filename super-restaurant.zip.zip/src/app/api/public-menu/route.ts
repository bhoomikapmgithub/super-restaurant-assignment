import { NextResponse } from "next/server";
import { db } from "@/server/db";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const slug = searchParams.get("slug");

  if (!slug) return NextResponse.json({ error: "Missing slug" }, { status: 400 });

  // fetch restaurant
  const restaurant = await db.restaurant.findFirst({
    where: { slug },
  });

  if (!restaurant)
    return NextResponse.json({ error: "Not found" }, { status: 404 });

  // fetch categories
  const categories = await db.category.findMany({
    where: { restaurantId: restaurant.id },
    orderBy: { createdAt: "asc" },
  });

  // fetch dishes with categories
  const dishes = await db.dish.findMany({
    where: { restaurantId: restaurant.id },
    include: { categories: true },
  });

  return NextResponse.json({ restaurant, categories, dishes });
}