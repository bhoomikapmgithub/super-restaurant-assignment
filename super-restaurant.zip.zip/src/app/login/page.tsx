"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<"email" | "otp">("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);

  const sendCode = async () => {
    setLoading(true);

    await fetch("/api/auth/send-code", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    setLoading(false);
    setStep("otp");
  };

  const verifyCode = async () => {
    setLoading(true);

    const res = await fetch("/api/auth/verify-code", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, code }),
    });

    setLoading(false);

    if (res.ok) {
      // SAVE LOGGED USER EMAIL HERE
      localStorage.setItem("userEmail", email);

      router.push("/dashboard");
    } else {
      const json = await res.json();
      alert(json?.error || "Invalid code");
    }
  };

  return (
    <div className="max-w-sm mx-auto mt-24 p-6">
      {step === "email" && (
        <>
          <Input
            value={email}
            placeholder="Enter email"
            onChange={(e) => setEmail(e.target.value)}
          />
          <Button className="w-full mt-4" onClick={sendCode} disabled={loading}>
            {loading ? "Sending..." : "Send Code"}
          </Button>
        </>
      )}

      {step === "otp" && (
        <>
          <Input
            value={code}
            placeholder="Enter OTP"
            onChange={(e) => setCode(e.target.value)}
          />
          <Button
            className="w-full mt-4"
            onClick={verifyCode}
            disabled={loading}
          >
            {loading ? "Verifying..." : "Verify Code"}
          </Button>
        </>
      )}
    </div>
  );
}