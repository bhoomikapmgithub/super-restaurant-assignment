"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function DashboardPage() {
  const [restaurants, setRestaurants] = useState([]);

  useEffect(() => {
    fetch("/api/restaurants")
      .then((res) => res.json())
      .then((data) => setRestaurants(data.items || []));
  }, []);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-xl font-semibold">Your Restaurants</h1>
        <Link href="/dashboard/restaurants/new">
          <Button>Create Restaurant</Button>
        </Link>
      </div>

      {restaurants.length === 0 && (
        <p className="text-gray-600">No restaurants created yet.</p>
      )}

      <div className="space-y-3">
        {restaurants.map((r: any) => (
          <Link
            key={r.id}
            href={`/dashboard/restaurants/${r.id}`}
            className="block border p-4 rounded hover:bg-gray-50"
          >
            <div className="font-medium">{r.name}</div>
            <div className="text-sm text-gray-600">{r.location}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}