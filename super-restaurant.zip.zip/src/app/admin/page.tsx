export default function AdminPage() {
  return (
    <main className="min-h-screen flex items-center justify-center">
      <div className="p-8 bg-white rounded shadow">
        <h1 className="text-2xl font-bold">🎉 Login Success — Welcome to Dashboard!</h1>
        <p className="mt-4">This is a simple admin landing page. Build your admin UI here.</p>
      </div>
    </main>
  );
}