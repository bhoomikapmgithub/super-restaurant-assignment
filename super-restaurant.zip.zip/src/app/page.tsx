"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function DashboardPage() {
  const [restaurants, setRestaurants] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const loadRestaurants = async () => {
    setLoading(true);

    const email = localStorage.getItem("userEmail");
    if (!email) return;

    const res = await fetch(`/api/restaurants?email=${email}`);
    const json = await res.json();

    setRestaurants(json.restaurants || []);
    setLoading(false);
  };

  useEffect(() => {
    loadRestaurants();
  }, []);

  return (
    <div className="max-w-3xl mx-auto mt-10 p-4">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Your Restaurants</h1>

        {/* Add New Restaurant Button */}
        <Link href="/dashboard/new-restaurant">
          <Button className="bg-black text-white">+ Add New Restaurant</Button>
        </Link>
      </div>

      {/* Empty State */}
      {!loading && restaurants.length === 0 && (
        <p className="text-gray-500 mt-4">No restaurants created yet.</p>
      )}

      {/* Restaurant List */}
      <div className="space-y-4">
        {restaurants.map((r) => (
          <div key={r.id} className="border rounded p-4 shadow-sm bg-white">
            <h2 className="text-xl font-semibold">{r.name}</h2>
            <p className="text-gray-600">{r.location}</p>

            <div className="flex gap-3 mt-4">
              <Link href={`/dashboard/restaurants/${r.id}/categories`}>
                <Button variant="outline">Categories</Button>
              </Link>

              <Link href={`/dashboard/restaurants/${r.id}/dishes`}>
                <Button variant="outline">Dishes</Button>
              </Link>

              <Link href={`/menu/${r.slug}`}>
                <Button className="bg-green-600 text-white">View Menu</Button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}