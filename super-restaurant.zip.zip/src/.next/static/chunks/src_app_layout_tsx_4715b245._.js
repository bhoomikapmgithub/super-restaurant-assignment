(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__61fa985e._.css",
  "static/chunks/node_modules__pnpm_a887ac3a._.js",
  "static/chunks/src_trpc_35beb76f._.js"
],
    source: "dynamic"
});
