(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_2909cd40._.js",
  "static/chunks/src_0fe0b52f._.js"
],
    source: "dynamic"
});
