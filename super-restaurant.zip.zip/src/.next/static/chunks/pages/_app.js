__turbopack_load_page_chunks__("/_app", [
  "static/chunks/b75fe_next_dist_compiled_next-devtools_index_579a2cc2.js",
  "static/chunks/b75fe_next_dist_compiled_dc9d1392._.js",
  "static/chunks/b75fe_next_dist_shared_lib_5ca2cac9._.js",
  "static/chunks/b75fe_next_dist_client_4d4c3655._.js",
  "static/chunks/b75fe_next_dist_10395a56._.js",
  "static/chunks/b75fe_next_app_ef97ebaf.js",
  "static/chunks/[next]_entry_page-loader_ts_43e2c0b6._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_d22e7e12._.js",
  "static/chunks/[root-of-the-server]__45f039c3._.js",
  "static/chunks/pages__app_2da965e7._.js",
  "static/chunks/turbopack-pages__app_94bd10a8._.js"
])
