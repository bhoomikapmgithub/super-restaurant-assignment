(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_f2a6fbd5._.js",
  "static/chunks/src_0021cd3d._.js"
],
    source: "dynamic"
});
