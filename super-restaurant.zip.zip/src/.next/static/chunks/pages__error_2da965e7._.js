(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b75fe_next_dist_compiled_next-devtools_index_579a2cc2.js",
  "static/chunks/b75fe_next_dist_compiled_dc9d1392._.js",
  "static/chunks/b75fe_next_dist_shared_lib_82ffaaa7._.js",
  "static/chunks/b75fe_next_dist_client_4d4c3655._.js",
  "static/chunks/b75fe_next_dist_59bdddf2._.js",
  "static/chunks/b75fe_next_error_e521235d.js",
  "static/chunks/[next]_entry_page-loader_ts_b8e49b6d._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_d22e7e12._.js",
  "static/chunks/[root-of-the-server]__092393de._.js"
],
    source: "entry"
});
