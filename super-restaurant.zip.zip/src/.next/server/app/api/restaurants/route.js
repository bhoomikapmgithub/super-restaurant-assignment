var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/restaurants/route.js")
R.c("server/chunks/b75fe_next_9a7fd101._.js")
R.c("server/chunks/[root-of-the-server]__5f8aadc3._.js")
R.m("[project]/.next-internal/server/app/api/restaurants/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/.pnpm/next@15.5.6_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/restaurants/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@15.5.6_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/restaurants/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
