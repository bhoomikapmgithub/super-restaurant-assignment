var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/send-code/route.js")
R.c("server/chunks/node_modules__pnpm_2b508e95._.js")
R.c("server/chunks/[root-of-the-server]__598db741._.js")
R.m("[project]/.next-internal/server/app/api/auth/send-code/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/.pnpm/next@15.5.6_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/send-code/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@15.5.6_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/send-code/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
